#!/bin/sh

./copy.sh
cd /tmp/postinstall
./postinstall.sh &

