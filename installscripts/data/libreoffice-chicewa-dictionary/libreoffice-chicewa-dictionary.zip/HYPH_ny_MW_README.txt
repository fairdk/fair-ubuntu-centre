Language: Chichewa (ny MW).
Origin:   None, empty implementation
License:  Creative Commons Non-Commercial Share-Alike
Author:   Benjamin Bach <benjamin@fairdanmark.dk>

This hyphenation dictionary is empty.

Licence:
http://creativecommons.org/licenses/by-nc/2.5/

HYPH ny MW hyph_ny_MW
