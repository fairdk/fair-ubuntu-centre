ETH="eth0"

try:
    from settings_customize import *
except:
    pass
