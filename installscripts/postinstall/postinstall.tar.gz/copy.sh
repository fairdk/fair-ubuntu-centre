#!/bin/sh

cd /tmp
mkdir postinstall
cd postinstall

cp -R /media/FAIR_POSTINSTALL/* .

exit

