Chichewa - Malawian spell checker
Version 0.1
Creative Commons Non-Commercial Share-Alike
